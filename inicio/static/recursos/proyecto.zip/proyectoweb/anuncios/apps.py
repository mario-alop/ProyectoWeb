from django.apps import AppConfig


class AnunciosConfig(AppConfig):
    default_auto_field = 'django.db.models.AutoField'
    name = 'anuncios'
    verbose_name = 'Noticias'
