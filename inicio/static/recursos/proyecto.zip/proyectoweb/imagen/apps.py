from django.apps import AppConfig


class ImagenConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'imagen'
